﻿using Microsoft.AspNetCore.Mvc;
using DemoAPI.Models; 
using DemoAPI.Data;   
using System.Threading.Tasks; 

namespace DemoAPI.Controllers
{
    [Route("api/[controller]")] 
    [ApiController]             
    public class LabelController : ControllerBase 
    {
        private readonly AppDbContext _context; 

        public LabelController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> PostLabel([FromBody] Label label)
        {
            if (label == null)
            {
                return BadRequest("Label data is null.");
            }

            
            if (string.IsNullOrWhiteSpace(label.name))
            {
                return BadRequest("Label name cannot be empty.");
            }

          
            if (label.Id != 0)
            {
                return BadRequest("Id should not be specified for a new Label.");
            }

            try
            { 
                _context.Labels.Add(label);

              await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetLabel), new { id = label.Id }, label);
            }
            catch (Exception ex)
            {
              
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

     
        [HttpGet("{id}")]
        public async Task<ActionResult<Label>> GetLabel(int id)
        {
            var label = await _context.Labels.FindAsync(id);

            if (label == null)
            {
                return NotFound();
            }

            return Ok(label); 
        }
        [HttpGet("")]
        public async Task<ActionResult<Label>> GetAllLabel()
        {
            var label =   _context.Labels;

            if (label == null)
            {
                return NotFound();
            }

            return Ok(label);
        }

    }
}