using System.Threading.Tasks;
using DemoAPI.Data;
using DemoAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DemoAPI.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class LabelController : ControllerBase
  {
    private readonly AppDbContext _context;

    public LabelController(AppDbContext context)
    {
      _context = context;
    }

    [HttpPost]
    [Consumes("application/json")]
    public async Task<IActionResult> PostLabel([FromBody] Label label)
    {
      if (label == null)
      {
        return BadRequest("Label data is null.");
      }


      if (string.IsNullOrWhiteSpace(label.name))
      {
        return BadRequest("Label name cannot be empty.");
      }


      if (label.Id != 0)
      {
        return BadRequest("Id should not be specified for a new Label.");
      }
      var existingLabel = await _context.Labels.FirstOrDefaultAsync(l => l.name == label.name);
      if (existingLabel != null)
      {
        return BadRequest($"A label with the name '{label.name}' already exists.");
      }
      try
      {
        _context.Labels.Add(label);

        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetLabel), new { id = label.Id }, label);
      }
      catch (Exception ex)
      {

        return StatusCode(500, $"Internal server error: {ex.Message}");
      }
    }

    // New EditLabel (Update) API
    [HttpPut("{id}")]
    public async Task<IActionResult> PutLabel(int id, [FromBody] Label label)
    {
      if (label == null)
      {
        return BadRequest("Label data is null.");
      }

      if (id != label.Id)
      {
        return BadRequest("Label ID mismatch.");
      }

     
      var existingLabel = await _context.Labels.FindAsync(id);

      if (existingLabel == null)
      {
        return NotFound($"Label with ID {id} not found.");
      }

      //  Validate the updated name
      if (string.IsNullOrWhiteSpace(label.name))
      {
        return BadRequest("Label name cannot be empty.");
      }

      //  Check for name uniqueness, excluding the current label being updated
      var duplicateLabel = await _context.Labels
          .FirstOrDefaultAsync(l => l.name == label.name && l.Id != id);

      if (duplicateLabel != null)
      {
        return BadRequest($"A label with the name '{label.name}' already exists.");
      }

      try
      {
        
        existingLabel.name = label.name;
        existingLabel.description = label.description; 
        existingLabel.color = label.color;                             

        _context.Labels.Update(existingLabel); 
        await _context.SaveChangesAsync();

        return NoContent();   }
      catch (DbUpdateConcurrencyException)
      {
         if (!await _context.Labels.AnyAsync(e => e.Id == id))
        {
          return NotFound($"Label with ID {id} not found after concurrency check.");
        }
        else
        {
          throw;  
        }
      }
      catch (Exception ex)
      {
        return StatusCode(500, $"Internal server error: {ex.Message}");
      }
    }
    [HttpGet("{id}")]
    public async Task<ActionResult<Label>> GetLabel(int id)
    {
      var label = await _context.Labels.FindAsync(id);

      if (label == null)
      {
        return NotFound();
      }

      return Ok(label);
    }
    [HttpGet("")]
    public async Task<ActionResult<Label>> GetAllLabel()
    {
      var label = _context.Labels;

      if (label == null)
      {
        return NotFound();
      }

      return Ok(label);
    }


    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteLabel(int id)
    {
      var label = await _context.Labels.FindAsync(id);
      if (label == null)
      {
        return NotFound($"Label with ID {id} not found.");
      }

      _context.Labels.Remove(label);
      await _context.SaveChangesAsync();

      return NoContent(); // 204 response
    }

  }
}
