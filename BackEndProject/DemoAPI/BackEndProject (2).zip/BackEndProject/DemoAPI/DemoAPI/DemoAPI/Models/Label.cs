using System;
using System.ComponentModel.DataAnnotations;

namespace DemoAPI.Models
{
    public class Label
    {
        [Key]
        public int Id { get; set; }
        public string name { get; set; }
       public string color { get; set; }
       public string description { get; set; }  
    }

    public class UserData
    {
        [Key]
        public int UserId { get; set; }
        public string Subject { get; set; }
        public string Sender {  get; set; }
        public string currentDate {  get; set; } 
    }
}
